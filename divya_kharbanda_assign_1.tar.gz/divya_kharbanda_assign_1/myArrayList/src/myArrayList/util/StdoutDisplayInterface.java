package myArrayList.util;

//This is an interfcae, its methods will be implemented by the class which uses this interface
public interface StdoutDisplayInterface 
{
	void writeToStdout(String testName);
}
